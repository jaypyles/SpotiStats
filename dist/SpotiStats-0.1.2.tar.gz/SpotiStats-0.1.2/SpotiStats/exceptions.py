class AuthenticationError(Exception):
    "User is not authenticated."
    pass

